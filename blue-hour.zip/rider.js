// A spring-driven surfing stance. Feet stay on the deck; hips load, chest follows,
// and flippers catch the weight instead of scaling the whole character.
export function spring(state,target,frequency,damping,dt){
 const n=Math.max(1,Math.ceil(dt*120)),h=dt/n,w=frequency*Math.PI*2;
 for(let i=0;i<n;i++){state.v+=(w*w*(target-state.x)-2*damping*w*state.v)*h;state.x+=state.v*h;}
 return state.x;
}
export function makeRider(T){
 const root=new T.Group(),bank=new T.Group();root.add(bank);
 const mats={shell:new T.MeshStandardMaterial({color:0x142334,roughness:.8}),white:new T.MeshStandardMaterial({color:0xfffcf0,roughness:.8}),gold:new T.MeshStandardMaterial({color:0xffb72f,roughness:.5}),eye:new T.MeshStandardMaterial({color:0x081320,roughness:.3}),deck:new T.MeshPhysicalMaterial({vertexColors:true,roughness:.36,clearcoat:.4,clearcoatRoughness:.3})};
 function mesh(parent,geo,material,scale,position){const m=new T.Mesh(geo,material);if(scale)m.scale.set(...scale);if(position)m.position.set(...position);parent.add(m);return m;}
 const sphere=(parent,mat,scale,pos)=>mesh(parent,new T.SphereGeometry(1,20,14),mat,scale,pos);
 // A tapered rail, domed deck and nose rocker replace the old flattened sphere.
 const rows=48,cols=12,verts=[],colors=[],indices=[],deckBase=[];
 const yellow=new T.Color('#ffd32d'),rail=new T.Color('#eaa51c'),stripe=new T.Color('#fff9df');
 for(let side=0;side<2;side++)for(let j=0;j<=rows;j++){const zt=j/rows*2-1,z=zt*1.36,half=.44*Math.sqrt(Math.max(.003,1-zt*zt))*(zt>0?.88:1);for(let i=0;i<=cols;i++){const across=i/cols*2-1,x=across*half,rocker=.15*Math.pow(Math.max(0,-zt),3)+.055*Math.pow(Math.max(0,zt),2);const y=rocker+(side===0?.052+.025*(1-across*across):-.045);verts.push(x,y,z);deckBase.push(y);const c=side===0&&Math.abs(across)<.09?stripe:Math.abs(across)>.90?rail:yellow;colors.push(c.r,c.g,c.b);}}
 const layer=(rows+1)*(cols+1);
 for(let side=0;side<2;side++)for(let j=0;j<rows;j++)for(let i=0;i<cols;i++){const a=side*layer+j*(cols+1)+i,b=a+cols+1;if(side===0)indices.push(a,b,a+1,b,b+1,a+1);else indices.push(a,a+1,b,b,a+1,b+1);}
 for(let j=0;j<rows;j++)for(const i of [0,cols]){const a=j*(cols+1)+i,b=a+cols+1;if(i===0)indices.push(a,a+layer,b,b,a+layer,b+layer);else indices.push(a,b,a+layer,b,b+layer,a+layer);}
 const boardGeo=new T.BufferGeometry();boardGeo.setAttribute('position',new T.Float32BufferAttribute(verts,3));boardGeo.setAttribute('color',new T.Float32BufferAttribute(colors,3));boardGeo.setIndex(indices);boardGeo.computeVertexNormals();mesh(bank,boardGeo,mats.deck);
 const pad=new T.MeshStandardMaterial({color:0x18475b,roughness:.95});for(let i=0;i<5;i++)mesh(bank,new T.BoxGeometry(.45-i*.025,.012,.045),pad,null,[0,.085,.48+i*.09]);
 const finGeo=new T.BufferGeometry();finGeo.setAttribute('position',new T.Float32BufferAttribute([0,0,0,0,-.25,.2,0,0,.34],3));finGeo.computeVertexNormals();const finMat=new T.MeshStandardMaterial({color:0xfff7d4,roughness:.5,side:T.DoubleSide});for(const x of [-.19,0,.19]){const fin=mesh(bank,finGeo,finMat,null,[x,-.035,x===0?.5:.35]);fin.scale.setScalar(x===0?1:.65);}
 const hips=new T.Group();hips.position.y=.47;bank.add(hips);
 const torso=new T.Group();hips.add(torso);
 sphere(torso,mats.shell,[.35,.46,.29],[0,.30,.025]);sphere(torso,mats.white,[.275,.36,.115],[0,.29,-.225]);
 const tail=sphere(torso,mats.shell,[.18,.11,.25],[0,-.025,.28]);tail.rotation.x=.2;
 const neck=new T.Group();neck.position.set(0,.65,-.06);torso.add(neck);
 sphere(neck,mats.shell,[.265,.27,.255],[0,0,0]);
 // White cheek patches and dark pupils make looking into a turn readable.
 for(const side of [-1,1]){sphere(neck,mats.white,[.105,.15,.13],[side*.15,-.015,-.17]);sphere(neck,mats.white,[.063,.067,.045],[side*.155,.035,-.265]);sphere(neck,mats.eye,[.031,.039,.025],[side*.155,.035,-.298]);sphere(neck,mats.white,[.009,.012,.006],[side*.145,.047,-.320]);}
 const beak=mesh(neck,new T.ConeGeometry(.115,.30,4),mats.gold,null,[0,-.075,-.35]);beak.rotation.x=-Math.PI/2;beak.scale.y=1.1;
 const flippers=[];for(const side of [-1,1]){const shoulder=new T.Group();shoulder.position.set(side*.30,.53,0);torso.add(shoulder);const elbow=new T.Group();elbow.position.y=-.27;shoulder.add(elbow);sphere(shoulder,mats.shell,[.095,.22,.105],[0,-.15,0]);sphere(elbow,mats.shell,[.10,.27,.09],[0,-.18,-.015]);flippers.push({shoulder,elbow,side});}
 const legs=[];for(const side of [-1,1]){const z=side<0?-.29:.33,x=side*.16,foot=sphere(bank,mats.gold,[.14,.055,.215],[x,.135,z-.035]);foot.rotation.y=side*.18;const thigh=mesh(bank,new T.CylinderGeometry(.075,.09,1,10),mats.shell),shin=mesh(bank,new T.CylinderGeometry(.055,.07,1,10),mats.shell);legs.push({side,x,z,foot,thigh,shin});}
 const axis=new T.Vector3(0,1,0),v=new T.Vector3();
 function link(m,from,to){v.subVectors(to,from);m.position.copy(from).add(to).multiplyScalar(.5);m.scale.y=v.length();m.quaternion.setFromUnitVectors(axis,v.normalize());}
 const states={edge:{x:0,v:0},load:{x:.1,v:0},twist:{x:0,v:0},shoulders:{x:0,v:0},head:{x:0,v:0},flex:{x:0,v:0}};let previousHeading=0,previousSpeed=18;
 function reset(heading=-.72){for(const st of Object.values(states)){st.x=st.v=0;}states.load.x=.18;previousHeading=heading;previousSpeed=18;}
 function update(dt,{heading,speed,crouch,snap,boost,baseTilt=0,time=0,active=true}){
 dt=Math.min(dt,.05);const rate=(heading-previousHeading)/Math.max(dt,.008);previousHeading=heading;const acceleration=(speed-previousSpeed)/Math.max(dt,.008);previousSpeed=speed;
 const bite=snap>=0?Math.sin(Math.PI*Math.min(1,snap/.38)):0,rebound=snap>=0?Math.sin(Math.PI*Math.min(1,Math.max(0,snap-.30)/.65)):0;
 const pressure=Math.min(1,Math.abs(heading)*.72+Math.abs(rate)*.08);
 const edge=spring(states.edge,-heading*.23-Math.max(-2,Math.min(2,rate))*.045+rebound*.08,4.7,.72,dt);
 const load=spring(states.load,Math.min(.7,.08+crouch*.62+pressure*.16+bite*.26-rebound*.10),3.8,.78,dt);
 const twist=spring(states.twist,-heading*.25-bite*.65,4.4,.82,dt);
 const chest=spring(states.shoulders,-heading*.14+baseTilt*.58+edge*.28,3.5,.8,dt);
 const gaze=spring(states.head,heading*.35+bite*.40,4.3,.88,dt);
 const flex=spring(states.flex,Math.max(-.018,Math.min(.025,acceleration*.0015))+bite*.026-rebound*.018,5.7,.68,dt);
 bank.rotation.set(-boost*.025+flex*.5, -bite*.10,edge);
 hips.position.set(-heading*.075,.49-load*.22,-.02-load*.05);
 torso.rotation.set(-.08-load*.24+rebound*.06,twist,chest);
 neck.rotation.set(load*.18,-gaze,-chest*.55);neck.position.y=.65;
 for(const f of flippers){const outside=Math.max(0,f.side*heading);f.shoulder.rotation.set(-.12-pressure*.12+bite*(f.side<0?-.6:.35),f.side*(.12+bite*.15),f.side*(.85+pressure*.45+outside*.27)+heading*.18);f.elbow.rotation.x=.15+load*.45+outside*.2;f.elbow.rotation.z=f.side*(load*.25+bite*.24);}
 for(const leg of legs){const ankle=new T.Vector3(leg.x,.18,leg.z),knee=new T.Vector3(leg.x-heading*.06,.32-load*.09,leg.z-.09-load*.12),hip=new T.Vector3(leg.x*.70+hips.position.x,hips.position.y+.04,hips.position.z+leg.z*.35);link(leg.thigh,hip,knee);link(leg.shin,knee,ankle);leg.foot.rotation.z=-edge*.2;}
 const positions=boardGeo.attributes.position.array;for(let i=0;i<deckBase.length;i++){const z=positions[i*3+2]/1.36;positions[i*3+1]=deckBase[i]+flex*Math.pow(Math.max(0,-z),2);}
 boardGeo.attributes.position.needsUpdate=true;
 // Near-neutral breathing is tiny; no idle wobble competes with rail contact.
 if(!active)hips.position.y+=Math.sin(time*2.4)*.006;
 return {edge,load,flex,bite,pressure};
 }
 return {root,update,reset};
}
