// The same travelling sections drive contact, visible water and move rewards.
export const WAVE_PLANS=[
 {name:'ROLLING POINT',duration:19,lip:6,close:13,height:1,width:1,pulse:.075,pace:.75},
 {name:'PUNCHY PEAK',duration:17,lip:4.5,close:11.5,height:1.13,width:.94,pulse:.105,pace:1.05},
 {name:'LONG SHOULDER',duration:21,lip:8,close:15,height:.92,width:1.12,pulse:.065,pace:.6}
];
export const wavePlan=n=>WAVE_PLANS[((n-1)%3+3)%3];
const bell=(x,w)=>{x=((x+34)%68+68)%68-34;return Math.exp(-x*x/(w*w));};
export function pocketAt(s,t){
 // Alternating peaks peel along the line; broad low shoulders separate them.
 const cycle=((s-t*3.5)%68+68)%68;
 const pocket=bell(cycle-20,10),ramp=bell(cycle-37,5.5);
 const breaking=bell(cycle-10,6.5);
 return {pocket,ramp,breaking,height:.40+.62*pocket+.40*ramp,cycle};
}
export function swell(q,s,t,shape){
 const high=Math.max(0,Math.min(1.3,q)),section=pocketAt(s,t);
 const travel=s*.055-t*shape.pace;
 return {x:high*high*(.14*Math.sin(travel)-section.breaking*.32),
 scale:shape.height*section.height*(1+shape.pulse*.4*Math.sin(travel)),
 ripple:.025*Math.sin(s*.9+q*8-t*2.3)+high*.025*Math.sin(s*.3-t*2.1),
 ...section};
}
