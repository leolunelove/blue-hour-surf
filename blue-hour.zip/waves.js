// Bounded swell sets: shared by the ride rules, mesh and contact surface.
export const WAVE_PLANS=[
 {name:'ROLLING POINT',duration:19,lip:6,close:13,height:1,width:1,pulse:.075,pace:.75},
 {name:'PUNCHY PEAK',duration:17,lip:4.5,close:11.5,height:1.13,width:.94,pulse:.105,pace:1.05},
 {name:'LONG SHOULDER',duration:21,lip:8,close:15,height:.92,width:1.12,pulse:.065,pace:.6}
];
export const wavePlan=n=>WAVE_PLANS[((n-1)%3+3)%3];
export function swell(q,s,t,shape){
 const high=Math.max(0,Math.min(1.3,q));
 const travel=s*.055-t*shape.pace;
 return {x:high*high*(.18*Math.sin(travel)+.09*Math.sin(travel*2.1+.7)),
 scale:shape.height*(1+shape.pulse*Math.sin(travel)+.025*Math.sin(travel*2.3)),
 ripple:.035*Math.sin(s*.9+q*8-t*2.3)+high*.035*Math.sin(s*.3-t*2.1)};
}
