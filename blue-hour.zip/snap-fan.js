export function makeSnapFan(T,scene){
 const geometry=new T.PlaneGeometry(1,1,30,9);
 const material=new T.MeshBasicMaterial({color:0xf4fffc,side:T.DoubleSide,transparent:true,opacity:0,depthWrite:false});
 material.onBeforeCompile=sh=>{sh.vertexShader=sh.vertexShader.replace('#include <common>','#include <common>\nvarying vec2 fanUv;').replace('#include <begin_vertex>','#include <begin_vertex>\nfanUv=uv;');sh.fragmentShader=sh.fragmentShader.replace('#include <common>',`#include <common>
varying vec2 fanUv;
float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1)),f.x),f.y);}
`).replace('#include <color_fragment>',`#include <color_fragment>
float radial=1.-fanUv.y;float grains=noise(fanUv*vec2(65.,35.));float fingers=noise(vec2(fanUv.x*65.,radial*3.));
float outer=1.-smoothstep(.65+fingers*.28,1.,radial);
float edge=pow(max(0.,sin(fanUv.x*3.14159)),.4);
diffuseColor.a*=outer*edge*smoothstep(.12,.42,grains)*smoothstep(0.,.12,radial);
`);};
 const mesh=new T.Mesh(geometry,material);mesh.frustumCulled=false;scene.add(mesh);
 let age=10;const origin=new T.Vector3(),across=new T.Vector3(),along=new T.Vector3(),normal=new T.Vector3();
 return {emit(f){age=0;origin.copy(f.p).addScaledVector(f.normal,.28).addScaledVector(f.forward,.6);across.copy(f.du);along.copy(f.forward);normal.copy(f.normal);},update(dt,f){age+=dt;if(f&&age<.85){const tail=f.p.clone().addScaledVector(f.normal,.28).addScaledVector(f.forward,.7);origin.lerp(tail,.45);}if(age>1.65){mesh.visible=false;return;}mesh.visible=true;material.opacity=Math.pow(1-age/1.65,.65)*.92;const p=geometry.attributes.position.array;let k=0;for(let j=0;j<=9;j++){const r=j/9;for(let i=0;i<=30;i++){const a=(i/30-.5)*2.5,spread=r*(.7+Math.min(age,1.1)*6.5);const v=origin.clone().addScaledVector(across,Math.cos(a)*spread*.55).addScaledVector(along,Math.sin(a)*spread).addScaledVector(normal,spread*.15+Math.sin(r*Math.PI)*age*.5);v.y-=age*age*1.1*r;p[k++]=v.x;p[k++]=v.y;p[k++]=v.z;}}geometry.attributes.position.needsUpdate=true;}};
}
