import assert from 'node:assert/strict';
import * as T from '../vendor/three.module.js';
import {spring,makeRider} from '../rider.js';
for(const hz of [30,60,120]){const s={x:0,v:0};for(let i=0;i<hz*2;i++)spring(s,1,4.7,.72,1/hz);assert.ok(Math.abs(s.x-1)<.0001,'Rail pressure must settle at every frame rate');}
const rig=makeRider(T);rig.reset();let edgePeak=0,flexPeak=0;
for(let i=0;i<1200;i++){const heading=Math.sin(i/55)*.9,snap=i%240<98?(i%240)/120:-1;const state=rig.update(1/120,{heading,speed:18+Math.sin(i/120)*5,crouch:.4,snap,boost:.3,baseTilt:-.4,time:i/120,active:true});edgePeak=Math.max(edgePeak,Math.abs(state.edge));flexPeak=Math.max(flexPeak,Math.abs(state.flex));rig.root.updateMatrixWorld(true);rig.root.traverse(n=>{for(const v of n.matrixWorld.elements)assert.ok(Number.isFinite(v),'Pose must stay finite through repeated reversals');});}
assert.ok(edgePeak>.15&&edgePeak<.5,'Board should bank visibly within a controlled range');assert.ok(flexPeak<.06,'Nose flex must stay subtle');
rig.root.traverse(n=>{if(n.geometry?.attributes.position)assert.ok([...n.geometry.attributes.position.array].every(Number.isFinite));});
console.log('PASS: spring settling at 30/60/120 fps; 10 seconds of reversals and snaps; finite rig and board geometry; bounded banking and flex.');
