import {wavePlan,swell} from './waves.js';
import * as T from './vendor/three.module.js';
import {makeSurfAudio} from './ocean.js?v=15';
import {makeRider} from './rider.js?v=2';
import {SurfSession,BOARDS,GOALS,loadSave,writeSave} from './session.js?v=5';
import {makeWhitewater} from './whitewater.js';
import {makeSnapFan} from './snap-fan.js?v=4';
const $=id=>document.getElementById(id), clamp=T.MathUtils.clamp, lerp=T.MathUtils.lerp;
const damp=(a,b,k,dt)=>lerp(a,b,1-Math.exp(-k*dt));
const scene=new T.Scene();scene.background=new T.Color('#78c3f4');scene.fog=new T.FogExp2('#b9dff3',.0029);
const renderer=new T.WebGLRenderer({antialias:true,powerPreference:'high-performance'});
renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,1.4));renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.05;document.body.prepend(renderer.domElement);
const camera=new T.PerspectiveCamera(56,innerWidth/innerHeight,.1,900);
scene.add(new T.HemisphereLight(0xe6f5ff,0x2a5278,2.2));const sun=new T.DirectionalLight(0xfff6dc,2.7);sun.position.set(-35,65,35);scene.add(sun);
let waveVisual=1;const waveShape={...wavePlan(1)};
// One authored open face. The small pitching lip can never turn into a fixed tunnel.
export function profile(q){
 if(q<=0)return {x:q*9,y:0};
 if(q<=1){const a=q*1.65;return {x:4.2*Math.sin(a),y:4.2*(1-Math.cos(a))};}
 const a=1.65+(q-1)*4.0;
 return {x:4.2*Math.sin(1.65)+.38*(Math.sin(a)-Math.sin(1.65)),y:4.2*(1-Math.cos(1.65))+.38*(Math.cos(1.65)-Math.cos(a))};
}
function sampleSurface(q,s,t,b=profile(q)){const w=swell(q,s,t,waveShape);return {x:b.x*waveShape.width+w.x,y:b.y*waveVisual*w.scale+w.ripple,z:-s};}
function surface(q,s,t){const p=sampleSurface(q,s,t);return new T.Vector3(p.x,p.y,p.z);}
function frame(q,s,t){const p=surface(q,s,t),du=surface(q+.002,s,t).sub(p).normalize(),forward=surface(q,s+.02,t).sub(p).normalize(),normal=new T.Vector3().crossVectors(du,forward).normalize();return {p,du,forward,normal};}
const waterUniforms={time:{value:0}};
const noise=`float hash(vec2 p){vec3 h=fract(vec3(p.xyx)*.1031);h+=dot(h,h.yzx+33.33);return fract((h.x+h.y)*h.z);}float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1.,0.)),f.x),mix(hash(i+vec2(0.,1.)),hash(i+vec2(1.)),f.x),f.y);}float fbm(vec2 p){return noise(p)*.55+noise(p*2.07+13.)*.29+noise(p*4.13-7.)*.16;}`;
const geo=new T.PlaneGeometry(1,1,112,104);const sections=new Float32Array(geo.attributes.position.count);geo.setAttribute('section',new T.BufferAttribute(sections,1));
const waterMaterial=new T.ShaderMaterial({side:T.DoubleSide,uniforms:waterUniforms,vertexShader:`attribute float section;varying float q;varying vec3 wp;varying vec3 wn;void main(){q=section;wp=(modelMatrix*vec4(position,1.)).xyz;wn=normalize(mat3(modelMatrix)*normal);gl_Position=projectionMatrix*viewMatrix*vec4(wp,1.);}`,fragmentShader:`uniform float time;varying float q;varying vec3 wp;varying vec3 wn;${noise}
void main(){
 vec2 uv=vec2(wp.x*1.5+wp.y*.9,wp.z*.72)+vec2(time*.17,time*.8);
 vec2 warp=vec2(fbm(uv*.36),fbm(uv*.36+7.));
 float h=fbm(uv+warp*1.4);float hx=fbm(uv+warp*1.4+vec2(.07,0.))-h;float hz=fbm(uv+warp*1.4+vec2(0.,.07))-h;
 vec3 N=normalize(wn+vec3(hx*1.9,hz*.35,hz*1.9));if(!gl_FrontFacing)N=-N;
 vec3 V=normalize(cameraPosition-wp);float fres=pow(1.-max(0.,dot(N,V)),3.);
 vec3 deep=vec3(.008,.115,.32),face=vec3(.008,.22,.42);
 vec3 c=mix(deep,face,smoothstep(.08,1.15,q)*.72);c*=.84+h*.34;
 vec3 R=reflect(-V,N);vec3 sky=mix(vec3(.06,.25,.60),vec3(.38,.64,.90),clamp(1.-R.y,0.,1.));
 c=mix(c,sky,fres*.17);
 float ripple=fbm(uv*3.5+warp*3.);float shine=pow(max(0.,dot(R,normalize(vec3(-.5,.8,.6)))),90.);
 c+=vec3(1.,.94,.78)*shine*.9;
 c+=vec3(.025,.055,.07)*smoothstep(.71,.86,ripple)*(.3+fres);
 vec2 fp=vec2(wp.z*.95+time*.8,q*19.-time*.9);vec2 fw=vec2(fbm(fp*.7),fbm(fp*.7+19.));
 float f=fbm(fp+fw*3.);float holes=noise(fp*5.+fw*4.);
 float lip=smoothstep(1.08,1.21,q)*smoothstep(.25,.54,f+holes*.15);
 float tendrils=smoothstep(.56,.73,fbm(vec2(wp.z*1.3+time*.6,q*8.-time*.8)+fw*3.))*smoothstep(.65,1.02,q)*.20;
 float lace=smoothstep(.65,.78,fbm(uv*.65+warp*3.))*smoothstep(.38,.61,ripple)*.10;
 float foam=clamp(lip+tendrils+lace,0.,1.);c=mix(c,vec3(.91,.97,1.)*(.88+holes*.12),foam);
 c+=vec3(.015,.07,.07)*smoothstep(.7,1.1,q)*(1.-foam);
 float fog=1.-exp(-length(cameraPosition-wp)*.003);c=mix(c,vec3(.58,.78,.94),fog);
 gl_FragColor=vec4(c,1.);
 #include <tonemapping_fragment>
 #include <colorspace_fragment>
}`});
const water=new T.Mesh(geo,waterMaterial);water.frustumCulled=false;scene.add(water);
// The distant water continues the blue face, rather than ending at a visible mesh edge.
const far=new T.Mesh(new T.PlaneGeometry(2200,2200),new T.MeshBasicMaterial({color:0x398ec7}));far.rotation.x=-Math.PI/2;far.position.y=-.16;scene.add(far);
const sky=new T.Mesh(new T.SphereGeometry(800,24,16),new T.ShaderMaterial({side:T.BackSide,depthWrite:false,vertexShader:'varying vec3 p;void main(){p=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:'varying vec3 p;void main(){float h=max(0.,normalize(p).y);gl_FragColor=vec4(mix(vec3(.70,.87,.98),vec3(.12,.46,.88),pow(h,.6)),1.);}'}));scene.add(sky);
function part(parent,g,color){const m=new T.Mesh(g,new T.MeshStandardMaterial({color,roughness:.65}));parent.add(m);return m;}
const islands=new T.Group();scene.add(islands);
for(let i=0;i<12;i++){const z=-60-i*65,x=-115-((i*31)%90),r=13+(i*11)%17;const rock=part(islands,new T.DodecahedronGeometry(r,0),i%2?0x85929c:0x758593);rock.position.set(x,2,z);rock.scale.set(1.8,.7+(i%3)*.4,1);const green=part(islands,new T.DodecahedronGeometry(r*.79,0),i%2?0x79985d:0x8ba663);green.position.set(x,7+(i%3)*3,z);green.scale.set(1.7,.42,1);}
const clouds=new T.Group();scene.add(clouds);for(let i=0;i<18;i++){const cloud=new T.Mesh(new T.IcosahedronGeometry(1,0),new T.MeshBasicMaterial({color:0xe5f3fc}));cloud.scale.set(10+i%4*4,1.5+i%3,4);cloud.position.set(-250+i*30,34+(i%3)*5,-230-i%4*40);clouds.add(cloud);}
// The subject has its own articulated stance and board-pressure springs.
const character=makeRider(T),surfer=character.root;scene.add(surfer);
const audio=makeSurfAudio(),fan=makeSnapFan(T,scene);
const dot=document.createElement('canvas');dot.width=dot.height=32;const dc=dot.getContext('2d'),dg=dc.createRadialGradient(16,16,1,16,16,16);dg.addColorStop(0,'#ffffffff');dg.addColorStop(.35,'#ffffffdd');dg.addColorStop(1,'#ffffff00');dc.fillStyle=dg;dc.fillRect(0,0,32,32);const map=new T.CanvasTexture(dot);
const count=1800,pp=new Float32Array(count*3),pv=new Float32Array(count*3),life=new Float32Array(count),pcol=new Float32Array(count*3);pp.fill(-1000);
const pg=new T.BufferGeometry();pg.setAttribute('position',new T.BufferAttribute(pp,3));pg.setAttribute('color',new T.BufferAttribute(pcol,3));
const spray=new T.Points(pg,new T.PointsMaterial({map,size:.23,color:0xffffff,vertexColors:true,transparent:true,opacity:.95,depthWrite:false}));spray.frustumCulled=false;
spray.material.onBeforeCompile=shader=>{shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
diffuseColor.a*=vColor.r;diffuseColor.rgb=vec3(1.);`);};
scene.add(spray);let particle=0;
function emit(f,n,power=1,railSide=1){const tail=f.p.clone().addScaledVector(f.forward,-1.05).addScaledVector(f.normal,.1);for(let j=0;j<n;j++){const i=particle++%count,k=i*3;pp[k]=tail.x+(Math.random()-.5)*.22;pp[k+1]=tail.y;pp[k+2]=tail.z;const lateral=(.6+Math.random()*4)*power*railSide;const vel=f.du.clone().multiplyScalar(lateral).addScaledVector(f.normal,(.5+Math.random()*2.5)*power).addScaledVector(f.forward,-Math.random()*4);pv[k]=vel.x;pv[k+1]=vel.y;pv[k+2]=vel.z;life[i]=.5+Math.random()*.65;}}
// White ribbon behind the board with feathered, broken edges.
const trail=[];const wg=new T.PlaneGeometry(1,1,1,60),wake=new T.Mesh(wg,new T.ShaderMaterial({transparent:true,side:T.DoubleSide,depthWrite:false,uniforms:waterUniforms,vertexShader:'varying vec2 v;void main(){v=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:`uniform float time;varying vec2 v;${noise}void main(){float edge=pow(max(0.,1.-abs(v.x*2.-1.)),.6);float a=edge*v.y*.65*smoothstep(.23,.58,fbm(v*vec2(12.,95.)+time*.2));gl_FragColor=vec4(.94,.98,1.,a);}`}));wake.frustumCulled=false;scene.add(wake);
let storage;try{storage=window.localStorage;}catch{storage=null;}
const game=new SurfSession(loadSave(storage));
let t=0,q=.50,s=0,speed=17,heading=-.15,lean=0,crouch=.2,snap=-1,boost=0,running=false,paused=false,acc=0,toastTime=0,rewardTime=0,ready=false,muted=false,view='menu',visualQ=.5,landPulse=0;
const keys={},commands={air:false,snap:false,bank:false},cam=new T.Vector3(),look=new T.Vector3(),up=new T.Vector3(0,1,0),targetRotation=new T.Quaternion(),basis=new T.Matrix4();
const whitewater=makeWhitewater(T,scene,map);
let padAir=false,padSnap=false,padBank=false,touchSteer=0;let unlockedThisRun=false;
function text(id,value){const el=$(id);const v=String(value);if(el.textContent!==v)el.textContent=v;}
function toast(value,duration=1.6){text('message',value);toastTime=duration;}
function reward(value){text('reward',value);rewardTime=4;}
function persist(){if(!writeSave(storage,game.save))text('saveNote','Progress saving is unavailable in this browser.');}
function drawGoals(){for(const id of ['menuGoals','pauseGoals','resultGoals']){$(id).replaceChildren();for(const goal of GOALS){const row=document.createElement('div');const done=game.save.badges.includes(goal.id);row.className='goal'+(done?' done':'');const stamp=document.createElement('span');stamp.className='stamp';stamp.textContent=done?'✓':'○';const copy=document.createElement('div'),title=document.createElement('b'),detail=document.createElement('p');title.textContent=goal.title;detail.textContent=goal.detail;copy.append(title,detail);row.append(stamp,copy);$(id).append(row);}}
 text('goalCount',`${game.save.badges.length} / 3`);text('menuGoalCount',`${game.save.badges.length} / 3`);text('bestScore',game.save.best.toLocaleString());
 const unlocked=game.save.badges.length>=2;for(const button of document.querySelectorAll('[data-board]')){const locked=button.dataset.board==='reef'&&!unlocked;button.setAttribute('aria-disabled',String(locked));button.setAttribute('aria-pressed',String(button.dataset.board===game.save.board));}
 text('reefLock',unlocked?'UNLOCKED':'2 STAMPS TO UNLOCK');document.querySelector('.unlock-note').textContent=unlocked?'Reef is unlocked. Choose the board that suits your line.':'Earn any 2 stamps to unlock the Reef board.';text('boardTradeoff',game.save.board==='reef'?'42% quicker turn response, stronger pumps and a higher top speed. A narrower clean-landing window.':'Stable rail response and a forgiving landing window.');
}
function selectBoard(id){if(!game.equip(id)){if(id==='reef')reward('Earn 2 beach stamps to unlock Reef.');return;}character.setBoard(BOARDS[id]);drawGoals();text('equipReef',id==='reef'?'Reef equipped ✓':'Equip Reef for the next session');handleEvents();}
function setView(value){view=value;document.body.dataset.view=value;$('menu').hidden=value!=='menu';$('pausePanel').hidden=value!=='paused';$('finish').hidden=value!=='results';}
function start(){unlockedThisRun=false;game.start();paused=false;acc=0;ready=false;visualQ=game.q;landPulse=0;character.reset();trail.length=0;life.fill(0);pp.fill(-1000);for(const key of Object.keys(keys))keys[key]=false;for(const key of Object.keys(commands))commands[key]=false;touchSteer=0;audio.start();setView('play');handleEvents();}
function pause(title='Find your line.'){if(!running||view==='results')return;paused=true;keys.KeyA=keys.KeyD=keys.ArrowLeft=keys.ArrowRight=false;touchSteer=0;text('pauseTitle',title);drawGoals();setView('paused');}
function resume(){paused=false;setView('play');}
function handleEvents(){for(const event of game.drain()){
 if(event.type==='move'){toast(event.same?'REPEAT · MIX UP YOUR LINE':event.text);$('combo').classList.remove('pulse');void $('combo').offsetWidth;$('combo').classList.add('pulse');audio.cue?.('move');}
 else if(event.type==='pump'){boost=.8;text('speedBurst',event.text);$('speedBurst').classList.remove('show');void $('speedBurst').offsetWidth;$('speedBurst').classList.add('show');audio.cue?.('pump');}
 else if(event.type==='spray'){const f=frame(q,s,t);fan.emit(f);emit(f,380,event.power||1.5);}
 else if(event.type==='launch'){emit(frame(q,s,t),100,1.15);toast(event.text,2);audio.cue?.('air');}
 else if(event.type==='land'){landPulse=event.clean?1:.6;emit(frame(q,s,t),event.clean?200:100,event.clean?1.2:.8);if(!event.clean)toast(event.text);audio.cue?.('land');}
 else if(event.type==='goal'){reward('STAMP EARNED · '+event.text.toUpperCase());drawGoals();audio.cue?.('goal');}
 else if(event.type==='unlock'){unlockedThisRun=true;reward(event.text);drawGoals();audio.cue?.('goal');}
 else if(event.type==='bank'){toast(event.text,2.8);text('bankValue','+'+event.value.toLocaleString());text('bankTitle',event.value>=1000?'BIG LINE BANKED':'FLOW IN THE BANK');$('bankCelebration').classList.remove('show');void $('bankCelebration').offsetWidth;$('bankCelebration').classList.add('show');audio.cue?.(event.value>=1000?'goal':'bank');}
 else if(event.type==='save')persist();
 else if(event.type==='finish'){paused=false;setView('results');drawGoals();text('result',game.banked.toLocaleString()+' flow');text('resultNote',game.banked===0&&game.stats.bottoms+game.stats.snaps>0?'Your stamps count. Next time, drop low or press B on the lower face to bank the line before it fades.':game.banked>=6000?'You beat Pip’s local score. Keep the line alive.':`Pip’s score: 6,000 · ${Math.max(0,6000-game.banked).toLocaleString()} more flow to beat the local.`);text('bestLine',game.stats.bestLine.toLocaleString());text('moveCount',game.stats.bottoms+game.stats.snaps+game.stats.cuts+game.stats.airs);text('wipeCount',game.stats.wipes);$('unlockBanner').hidden=!unlockedThisRun;text('equipReef',game.save.board==='reef'?'Reef equipped ✓':'Equip Reef for the next session');}
 else if(event.text)toast(event.text,event.type==='wave'?2.2:1.5);
 }}
function sync(dt){const plan=game.plan();for(const key of ['height','width','pulse','pace'])waveShape[key]=damp(waveShape[key],plan[key],1.8,dt);running=['surf','air','between','recover'].includes(game.phase);if(view==='menu'){q=.5;s=0;speed=17;heading=-.12;lean=-.1;crouch=.2;snap=-1;boost=0;visualQ=q;}else{visualQ=damp(visualQ,game.q,10,dt);q=visualQ;s=game.s;speed=game.speed;heading=game.heading;lean=game.lean;crouch=game.crouch;snap=game.snap;boost=game.boost;}landPulse*=Math.exp(-dt*7);waveVisual=damp(waveVisual,['recover','between'].includes(game.phase)?.20:1,2.3,dt);}
function input(){let steer=touchSteer||(keys.KeyD||keys.ArrowRight?1:0)-(keys.KeyA||keys.ArrowLeft?1:0);try{const p=navigator.getGamepads?.()[0];if(p){if(Math.abs(p.axes[0])>.15)steer=p.axes[0];const a=!!p.buttons[0]?.pressed,b=!!p.buttons[1]?.pressed,c=!!p.buttons[2]?.pressed;if(a&&!padAir)commands.air=true;if(b&&!padSnap)commands.snap=true;if(c&&!padBank)commands.bank=true;padAir=a;padSnap=b;padBank=c;}}catch{}return steer;}
function updateHud(){const section=game.section();document.body.dataset.phase=game.phase;document.body.dataset.section=section.id;text('speed',Math.round(speed*3.6));const seconds=Math.ceil(Math.max(0,120-game.elapsed));text('time',`${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`);text('score',game.banked.toLocaleString());text('waveNumber',`WAVE ${String(game.wave).padStart(2,'0')} · ${game.board.name.toUpperCase()}`);text('rivalProgress',game.banked>=6000?'PIP’S SCORE BEATEN ✓':`${Math.max(0,6000-game.banked).toLocaleString()} TO BEAT PIP`);text('sectionName',game.phase==='between'?'NEXT SWELL':game.phase==='recover'?'WHITEWATER':section.name);text('waveCountdown',game.phase==='between'||game.phase==='recover'?`${Math.ceil(game.transition)}s to drop in`:`${Math.ceil(Math.max(0,game.plan().duration-game.waveTime))}s to next swell`);text('sectionHint',game.opportunity());$('sectionFill').style.width=`${clamp(game.waveTime/game.plan().duration,0,1)*100}%`;$('energyFill').style.width=`${game.charge*100}%`;text('energyLabel',game.phase==='surf'&&game.q>.65&&game.speed>=17.2&&game.waveTime>.8&&game.recovery<=.1?'SPACE · AIR READY':game.boost>.1?'SPEED RELEASED':game.charge>.6?'LOADED · DRIVE RIGHT':'LOAD THE RAIL');text('comboValue',game.line.toLocaleString());text('multiplier','×'+game.multiplier.toFixed(1));text('moveTrail',game.recent.length?game.recent.join(' → '):'Your next line starts with a bottom turn');text('bankHint',game.line?(game.q<.32?'B TO BANK · OR LINK ANOTHER MOVE':'DROP LOW TO BANK · LINK ANOTHER MOVE FOR MORE'):'A drop · D drive · S snap · Space air');$('combo').classList.toggle('empty',!game.line);$('linkFill').style.width=`${clamp(game.linkTime/6.5,0,1)*100}%`;if(game.air)$('landingDot').style.left=`${50+game.air.lean*48}%`;}
const waterCross=Array.from({length:113},(_,i)=>{const f=i/112,q=f<.48?-36+f/.48*36:(f-.48)/.52*1.38;return {q,...profile(q),high:clamp(q,0,1.3)};});
function render(dt){
 sync(dt);waterUniforms.time.value=t;const pos=geo.attributes.position.array;let k=0;
 for(let j=0;j<=104;j++){const dist=s-32+j/104*235,pulse=Math.sin(dist*.075-t*1.3),scale=1+.035*Math.sin(dist*.066-t*.85);for(const c of waterCross){const p=sampleSurface(c.q,dist,t,c);pos[k*3]=p.x;pos[k*3+1]=p.y;pos[k*3+2]=p.z;sections[k++]=c.q;}}
 geo.attributes.position.needsUpdate=true;geo.attributes.section.needsUpdate=true;geo.computeVertexNormals();
 const f=frame(q,s,t),modelUp=new T.Vector3(0,1,0).lerp(f.normal,.42).normalize();
 const forward=f.forward.clone().multiplyScalar(Math.cos(heading*.6)).addScaledVector(f.du,Math.sin(heading*.6));
 forward.addScaledVector(modelUp,-forward.dot(modelUp)).normalize();
 const right=new T.Vector3().crossVectors(forward,modelUp).normalize();
 basis.makeBasis(right,modelUp,forward.clone().negate());targetRotation.setFromRotationMatrix(basis);surfer.quaternion.slerp(targetRotation,1-Math.exp(-dt*11));surfer.position.copy(f.p).addScaledVector(f.normal,.11);if(game.phase==='recover'&&view!=='menu'){const wash=1-game.transition/2;surfer.position.y-=Math.sin(wash*Math.PI)*.08;}if(game.air&&view!=='menu'){surfer.position.y+=game.air.height;surfer.position.addScaledVector(f.normal,Math.sin(game.air.age/game.air.duration*Math.PI)*.35);surfer.rotateX(game.air.spin*.5);}
 const stance=character.update(dt,{heading,speed,crouch,snap,boost,baseTilt:Math.atan2(modelUp.x,modelUp.y),time:t,active:running,air:game.air?Math.sin(Math.PI*clamp(game.air.age/game.air.duration,0,1)):0,landing:landPulse});
 if(running&&!paused&&game.phase==='surf'){emit(f,Math.ceil((55+Math.abs(heading)*110+stance.pressure*90+boost*100)*dt),.65+stance.pressure*.45,heading>0?-1:1);trail.unshift({q,s});if(trail.length>61)trail.pop();}
 const wa=wg.attributes.position.array;for(let j=0;j<=60;j++){for(let i=0;i<=1;i++){const item=trail[Math.min(j,trail.length-1)];const idx=(j*2+i)*3;if(item){const p=surface(item.q+(i?1:-1)*(.018+j*.00045),item.s-1.1,t);const n=frame(item.q,item.s,t).normal;p.addScaledVector(n,.035);wa[idx]=p.x;wa[idx+1]=p.y;wa[idx+2]=p.z;}else wa[idx+1]=-1000;}}wg.attributes.position.needsUpdate=true;
 for(let i=0;i<count;i++){const k=i*3;if(life[i]>0){life[i]-=dt;pv[k+1]-=dt*5.5;pp[k]+=pv[k]*dt;pp[k+1]+=pv[k+1]*dt;pp[k+2]+=pv[k+2]*dt;const fade=clamp(life[i]*2,0,1);pcol[k]=pcol[k+1]=pcol[k+2]=fade;}else{pp[k+1]=-1000;pcol[k]=pcol[k+1]=pcol[k+2]=0;}}pg.attributes.position.needsUpdate=true;pg.attributes.color.needsUpdate=true;
 // Sparse wind-carried crest spray, added to the same bounded pool.
 if(running){for(let j=0;j<Math.ceil(dt*65);j++){const dist=s+5+Math.random()*55;const cf=frame(1.18,dist,t);emit(cf,1,.6);}}
 fan.update(dt,snap>=0?f:null);const closing=clamp((game.waveTime-game.plan().close)/(game.plan().duration-game.plan().close),0,1);whitewater.update(t,s-38+closing*34,0,(game.phase==='surf'&&closing>.08)||game.phase==='recover',closing);
 const desired=new T.Vector3(f.p.x-3.1,Math.max(f.p.y+2.65,surface(1,s,t).y+2.3)+(game.air?game.air.height*.70:0),-s+5.0+Math.max(0,1.0-camera.aspect)*.7);
 const aim=new T.Vector3(f.p.x-.75,f.p.y+.70+(game.air?game.air.height*.85:0),-s-2.8);
 if(!ready){cam.copy(desired);look.copy(aim);ready=true;}
 cam.lerp(desired,1-Math.exp(-dt*5));look.lerp(aim,1-Math.exp(-dt*5.5));cam.y=Math.max(cam.y,surface(1,s,t).y+1.6);camera.position.copy(cam);up.set(Math.sin(lean*.035),1,0).normalize();camera.up.lerp(up,1-Math.exp(-dt*3));camera.lookAt(look);camera.fov=damp(camera.fov,55+clamp(speed-18,0,10)*.35+boost*1.4,2.5,dt);camera.updateProjectionMatrix();
 sky.position.z=-s;far.position.z=-s;clouds.position.z=-s*.8;islands.position.z=-Math.floor(s/650)*650;
 updateHud();
 if(toastTime>0){toastTime-=dt;if(toastTime<=0)text('message','');}if(rewardTime>0){rewardTime-=dt;if(rewardTime<=0)text('reward','');}
 renderer.render(scene,camera);
}
$('start').onclick=start;$('again').onclick=start;$('pause').onclick=()=>pause();$('resume').onclick=resume;$('goalButton').onclick=()=>pause('Your beach stamps.');$('endSession').onclick=()=>{game.finish();handleEvents();};$('garage').onclick=()=>{setView('menu');paused=false;ready=false;drawGoals();};$('equipReef').onclick=()=>selectBoard('reef');
$('sound').onclick=()=>{muted=!audio.toggle();text('sound',muted?'Sound off':'Sound on');};
for(const button of document.querySelectorAll('[data-board]'))button.onclick=()=>selectBoard(button.dataset.board);
window.addEventListener('keydown',e=>{if(['Space','ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.code))e.preventDefault();keys[e.code]=true;if(e.repeat)return;if(e.code==='KeyP'||e.code==='Escape'){if(view==='paused')resume();else if(view==='play')pause();}if(e.code==='KeyR'&&view!=='menu')start();if(e.code==='KeyM')$('sound').click();if(view==='play'&&!paused){if(e.code==='Space')commands.air=true;if(e.code==='KeyS')commands.snap=true;if(e.code==='KeyB')commands.bank=true;}});
window.addEventListener('keyup',e=>keys[e.code]=false);window.addEventListener('blur',()=>{for(const key of Object.keys(keys))keys[key]=false;if(view==='play')pause();});document.addEventListener('visibilitychange',()=>{if(document.hidden&&view==='play')pause();});
for(const b of document.querySelectorAll('[data-steer],[data-action]')){b.onpointerdown=e=>{e.preventDefault();b.setPointerCapture(e.pointerId);if(b.dataset.steer)touchSteer=Number(b.dataset.steer);else commands[b.dataset.action]=true;};b.onpointerup=b.onpointercancel=()=>{if(b.dataset.steer)touchSteer=0;};}
const clock=new T.Clock();function animate(){requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.10);if(!paused){t+=dt;if(['surf','air','between','recover'].includes(game.phase)&&view==='play'){acc+=dt;const steer=input();while(acc>=1/120){game.update(1/120,{steer,...commands});for(const key of Object.keys(commands))commands[key]=false;acc-=1/120;}handleEvents();}render(dt);}audio.update({speed,steer:heading,air:game.phase==='air',paused,running:running&&view==='play',time:t,u:q*4,landing:Math.max(boost,landPulse)});}drawGoals();character.setBoard(BOARDS[game.save.board]);setView('menu');$('loading').hidden=true;animate();
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
