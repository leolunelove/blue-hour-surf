import * as T from './vendor/three.module.js';
import {makeSurfAudio} from './ocean.js?v=14';
import {makeRider} from './rider.js?v=1';
import {makeSnapFan} from './snap-fan.js?v=4';
const $=id=>document.getElementById(id), clamp=T.MathUtils.clamp, lerp=T.MathUtils.lerp;
const damp=(a,b,k,dt)=>lerp(a,b,1-Math.exp(-k*dt));
const scene=new T.Scene();scene.background=new T.Color('#78c3f4');scene.fog=new T.FogExp2('#b9dff3',.0029);
const renderer=new T.WebGLRenderer({antialias:true,powerPreference:'high-performance'});
renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,1.4));renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.05;document.body.prepend(renderer.domElement);
const camera=new T.PerspectiveCamera(56,innerWidth/innerHeight,.1,900);
scene.add(new T.HemisphereLight(0xe6f5ff,0x2a5278,2.2));const sun=new T.DirectionalLight(0xfff6dc,2.7);sun.position.set(-35,65,35);scene.add(sun);
// One authored open face. The small pitching lip can never turn into a fixed tunnel.
export function profile(q){
 if(q<=0)return {x:q*9,y:0};
 if(q<=1){const a=q*1.65;return {x:4.2*Math.sin(a),y:4.2*(1-Math.cos(a))};}
 const a=1.65+(q-1)*6.5;
 return {x:4.2*Math.sin(1.65)+.9*(Math.sin(a)-Math.sin(1.65)),y:4.2*(1-Math.cos(1.65))+.9*(Math.cos(1.65)-Math.cos(a))};
}
function surface(q,s,t){const b=profile(q),high=clamp(q,0,1.3),pulse=Math.sin(s*.075-t*1.3);return new T.Vector3(b.x+high*high*.14*pulse,b.y*(1+.035*Math.sin(s*.066-t*.85))+.035*Math.sin(s*.9+q*8-t*2.3),-s);}
function frame(q,s,t){const p=surface(q,s,t),du=surface(q+.002,s,t).sub(p).normalize(),forward=surface(q,s+.02,t).sub(p).normalize(),normal=new T.Vector3().crossVectors(du,forward).normalize();return {p,du,forward,normal};}
const waterUniforms={time:{value:0}};
const noise=`float hash(vec2 p){vec3 h=fract(vec3(p.xyx)*.1031);h+=dot(h,h.yzx+33.33);return fract((h.x+h.y)*h.z);}float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1.,0.)),f.x),mix(hash(i+vec2(0.,1.)),hash(i+vec2(1.)),f.x),f.y);}float fbm(vec2 p){return noise(p)*.55+noise(p*2.07+13.)*.29+noise(p*4.13-7.)*.16;}`;
const geo=new T.PlaneGeometry(1,1,112,104);const sections=new Float32Array(geo.attributes.position.count);geo.setAttribute('section',new T.BufferAttribute(sections,1));
const waterMaterial=new T.ShaderMaterial({side:T.DoubleSide,uniforms:waterUniforms,vertexShader:`attribute float section;varying float q;varying vec3 wp;varying vec3 wn;void main(){q=section;wp=(modelMatrix*vec4(position,1.)).xyz;wn=normalize(mat3(modelMatrix)*normal);gl_Position=projectionMatrix*viewMatrix*vec4(wp,1.);}`,fragmentShader:`uniform float time;varying float q;varying vec3 wp;varying vec3 wn;${noise}
void main(){
 vec2 uv=vec2(wp.x*1.5+wp.y*.9,wp.z*.72)+vec2(time*.17,time*.8);
 vec2 warp=vec2(fbm(uv*.36),fbm(uv*.36+7.));
 float h=fbm(uv+warp*1.4);float hx=fbm(uv+warp*1.4+vec2(.07,0.))-h;float hz=fbm(uv+warp*1.4+vec2(0.,.07))-h;
 vec3 N=normalize(wn+vec3(hx*1.9,hz*.35,hz*1.9));if(!gl_FrontFacing)N=-N;
 vec3 V=normalize(cameraPosition-wp);float fres=pow(1.-max(0.,dot(N,V)),3.);
 vec3 deep=vec3(.008,.115,.32),face=vec3(.008,.22,.42);
 vec3 c=mix(deep,face,smoothstep(.08,1.15,q)*.72);c*=.84+h*.34;
 vec3 R=reflect(-V,N);vec3 sky=mix(vec3(.06,.25,.60),vec3(.38,.64,.90),clamp(1.-R.y,0.,1.));
 c=mix(c,sky,fres*.17);
 float ripple=fbm(uv*3.5+warp*3.);float shine=pow(max(0.,dot(R,normalize(vec3(-.5,.8,.6)))),90.);
 c+=vec3(1.,.94,.78)*shine*.9;
 c+=vec3(.025,.055,.07)*smoothstep(.71,.86,ripple)*(.3+fres);
 vec2 fp=vec2(wp.z*.95+time*.8,q*19.-time*.9);vec2 fw=vec2(fbm(fp*.7),fbm(fp*.7+19.));
 float f=fbm(fp+fw*3.);float holes=noise(fp*5.+fw*4.);
 float lip=smoothstep(1.08,1.21,q)*smoothstep(.25,.54,f+holes*.15);
 float tendrils=smoothstep(.56,.73,fbm(vec2(wp.z*1.3+time*.6,q*8.-time*.8)+fw*3.))*smoothstep(.65,1.02,q)*.20;
 float lace=smoothstep(.65,.78,fbm(uv*.65+warp*3.))*smoothstep(.38,.61,ripple)*.10;
 float foam=clamp(lip+tendrils+lace,0.,1.);c=mix(c,vec3(.91,.97,1.)*(.88+holes*.12),foam);
 c+=vec3(.015,.07,.07)*smoothstep(.7,1.1,q)*(1.-foam);
 float fog=1.-exp(-length(cameraPosition-wp)*.003);c=mix(c,vec3(.58,.78,.94),fog);
 gl_FragColor=vec4(c,1.);
 #include <tonemapping_fragment>
 #include <colorspace_fragment>
}`});
const water=new T.Mesh(geo,waterMaterial);water.frustumCulled=false;scene.add(water);
// The distant water continues the blue face, rather than ending at a visible mesh edge.
const far=new T.Mesh(new T.PlaneGeometry(2200,2200),new T.MeshBasicMaterial({color:0x398ec7}));far.rotation.x=-Math.PI/2;far.position.y=-.16;scene.add(far);
const sky=new T.Mesh(new T.SphereGeometry(800,24,16),new T.ShaderMaterial({side:T.BackSide,depthWrite:false,vertexShader:'varying vec3 p;void main(){p=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:'varying vec3 p;void main(){float h=max(0.,normalize(p).y);gl_FragColor=vec4(mix(vec3(.70,.87,.98),vec3(.12,.46,.88),pow(h,.6)),1.);}'}));scene.add(sky);
function part(parent,g,color){const m=new T.Mesh(g,new T.MeshStandardMaterial({color,roughness:.65}));parent.add(m);return m;}
const islands=new T.Group();scene.add(islands);
for(let i=0;i<12;i++){const z=-60-i*65,x=-115-((i*31)%90),r=13+(i*11)%17;const rock=part(islands,new T.DodecahedronGeometry(r,0),i%2?0x85929c:0x758593);rock.position.set(x,2,z);rock.scale.set(1.8,.7+(i%3)*.4,1);const green=part(islands,new T.DodecahedronGeometry(r*.79,0),i%2?0x79985d:0x8ba663);green.position.set(x,7+(i%3)*3,z);green.scale.set(1.7,.42,1);}
const clouds=new T.Group();scene.add(clouds);for(let i=0;i<18;i++){const cloud=new T.Mesh(new T.IcosahedronGeometry(1,0),new T.MeshBasicMaterial({color:0xe5f3fc}));cloud.scale.set(10+i%4*4,1.5+i%3,4);cloud.position.set(-250+i*30,34+(i%3)*5,-230-i%4*40);clouds.add(cloud);}
// The subject has its own articulated stance and board-pressure springs.
const character=makeRider(T),surfer=character.root;scene.add(surfer);
const audio=makeSurfAudio(),fan=makeSnapFan(T,scene);
const dot=document.createElement('canvas');dot.width=dot.height=32;const dc=dot.getContext('2d'),dg=dc.createRadialGradient(16,16,1,16,16,16);dg.addColorStop(0,'#ffffffff');dg.addColorStop(.35,'#ffffffdd');dg.addColorStop(1,'#ffffff00');dc.fillStyle=dg;dc.fillRect(0,0,32,32);const map=new T.CanvasTexture(dot);
const count=1800,pp=new Float32Array(count*3),pv=new Float32Array(count*3),life=new Float32Array(count),pcol=new Float32Array(count*3);pp.fill(-1000);
const pg=new T.BufferGeometry();pg.setAttribute('position',new T.BufferAttribute(pp,3));pg.setAttribute('color',new T.BufferAttribute(pcol,3));
const spray=new T.Points(pg,new T.PointsMaterial({map,size:.23,color:0xffffff,vertexColors:true,transparent:true,opacity:.95,depthWrite:false}));spray.frustumCulled=false;
spray.material.onBeforeCompile=shader=>{shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
diffuseColor.a*=vColor.r;diffuseColor.rgb=vec3(1.);`);};
scene.add(spray);let particle=0;
function emit(f,n,power=1,railSide=1){const tail=f.p.clone().addScaledVector(f.forward,-1.05).addScaledVector(f.normal,.1);for(let j=0;j<n;j++){const i=particle++%count,k=i*3;pp[k]=tail.x+(Math.random()-.5)*.22;pp[k+1]=tail.y;pp[k+2]=tail.z;const lateral=(.6+Math.random()*4)*power*railSide;const vel=f.du.clone().multiplyScalar(lateral).addScaledVector(f.normal,(.5+Math.random()*2.5)*power).addScaledVector(f.forward,-Math.random()*4);pv[k]=vel.x;pv[k+1]=vel.y;pv[k+2]=vel.z;life[i]=.5+Math.random()*.65;}}
// White ribbon behind the board with feathered, broken edges.
const trail=[];const wg=new T.PlaneGeometry(1,1,1,60),wake=new T.Mesh(wg,new T.ShaderMaterial({transparent:true,side:T.DoubleSide,depthWrite:false,uniforms:waterUniforms,vertexShader:'varying vec2 v;void main(){v=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:`uniform float time;varying vec2 v;${noise}void main(){float edge=pow(max(0.,1.-abs(v.x*2.-1.)),.6);float a=edge*v.y*.65*smoothstep(.23,.58,fbm(v*vec2(12.,95.)+time*.2));gl_FragColor=vec4(.94,.98,1.,a);}`}));wake.frustumCulled=false;scene.add(wake);
let t=0,q=.84,s=0,speed=18,heading=-.72,lean=0,crouch=0,elapsed=0,score=0,snaps=0,bottoms=0,snap=-1,recovery=0,charge=0,lastSide=-1,running=false,paused=false,acc=0,toastTime=0,boost=0,ready=false,muted=false;
const keys={},cam=new T.Vector3(),look=new T.Vector3(),up=new T.Vector3(0,1,0),targetRotation=new T.Quaternion(),basis=new T.Matrix4();
function toast(text){$('message').textContent=text;toastTime=1.2;}
function start(){character.reset();q=.84;s=0;speed=18;heading=-.72;lean=0;crouch=.2;elapsed=0;score=0;snaps=0;bottoms=0;snap=-1;recovery=0;charge=0;lastSide=-1;running=true;paused=false;ready=false;acc=0;boost=0;trail.length=0;life.fill(0);pp.fill(-1000);$('intro').style.display='none';$('finish').style.display='none';audio.start();toast('DROP IN · A LEFT / D RIGHT');}
function doSnap(){if(snap>=0||recovery>0||q<.72)return;snap=0;recovery=1.0;snaps++;score+=150+Math.round(speed*4);boost=.8;const f=frame(q,s,t);fan.emit(f);emit(f,380,1.7);toast('LIP SNAP · DRIVE BACK DOWN');}
function step(dt){
 elapsed+=dt;let input=(keys.KeyD||keys.ArrowRight?1:0)-(keys.KeyA||keys.ArrowLeft?1:0);const pad=navigator.getGamepads?.()[0];if(pad&&Math.abs(pad.axes[0])>.15)input=pad.axes[0];
 recovery=Math.max(0,recovery-dt);boost=Math.max(0,boost-dt);if(snap>=0){snap+=dt;if(snap>.82)snap=-1;}
 let target=input*.91;if(snap>=0)target=lerp(.65,-1.0,T.MathUtils.smoothstep(snap,0,.24));else if(recovery>0)target=lerp(target,-.82,recovery/.18);
 if(elapsed<.7)target=-.72;
 if(q<.08&&target<0)target=.28;
 heading=damp(heading,target,snap>=0?13:5.6,dt);
 const down=-Math.sin(heading);charge=clamp(charge+Math.max(0,down)*dt*1.2-dt*.12,0,1);
 if(input>.35&&lastSide<0&&q<.36&&charge>.22&&recovery<=0){speed+=2.4+charge*2.5;boost=.8;score+=100;bottoms++;charge=0;toast('BOTTOM TURN · SPEED BUILT');}
 if(Math.abs(input)>.35)lastSide=Math.sign(input);
 speed+=((18-speed)*.38+down*(q>.12?6.8:1.5)-Math.abs(input)*.15)*dt;speed=clamp(speed,13,28);
 q+=Math.sin(heading)*speed*.055*dt;q=clamp(q,.025,.965);s+=Math.cos(heading)*speed*dt;
 if((q>=.955&&heading>.08)||(keys.KeyS&&q>.72))doSnap();
 lean=damp(lean,heading*1.0,8,dt);crouch=damp(crouch,.12+Math.abs(input)*.23+Math.max(0,down)*.16+(snap>=0?Math.sin(snap/.82*Math.PI)*.25:0),9,dt);
 score+=dt*(8+Math.abs(heading)*speed*.55);
 if(elapsed>=15){running=false;$('finish').style.display='flex';$('result').textContent=`${Math.floor(score).toLocaleString()} flow`;$('summary').textContent=`${bottoms} bottom turns · ${snaps} lip snaps · R to ride again`;}
}
const waterCross=Array.from({length:113},(_,i)=>{const f=i/112,q=f<.48?-36+f/.48*36:(f-.48)/.52*1.38;return {q,...profile(q),high:clamp(q,0,1.3)};});
function render(dt){
 waterUniforms.time.value=t;const pos=geo.attributes.position.array;let k=0;
 for(let j=0;j<=104;j++){const dist=s-32+j/104*235,pulse=Math.sin(dist*.075-t*1.3),scale=1+.035*Math.sin(dist*.066-t*.85);for(const c of waterCross){pos[k*3]=c.x+c.high*c.high*.14*pulse;pos[k*3+1]=c.y*scale+.035*Math.sin(dist*.9+c.q*8-t*2.3);pos[k*3+2]=-dist;sections[k++]=c.q;}}
 geo.attributes.position.needsUpdate=true;geo.attributes.section.needsUpdate=true;geo.computeVertexNormals();
 const f=frame(q,s,t),modelUp=new T.Vector3(0,1,0).lerp(f.normal,.42).normalize();
 const forward=f.forward.clone().multiplyScalar(Math.cos(heading*.6)).addScaledVector(f.du,Math.sin(heading*.6));
 forward.addScaledVector(modelUp,-forward.dot(modelUp)).normalize();
 const right=new T.Vector3().crossVectors(forward,modelUp).normalize();
 basis.makeBasis(right,modelUp,forward.clone().negate());targetRotation.setFromRotationMatrix(basis);surfer.quaternion.slerp(targetRotation,1-Math.exp(-dt*11));surfer.position.copy(f.p).addScaledVector(f.normal,.11);
 const stance=character.update(dt,{heading,speed,crouch,snap,boost,baseTilt:Math.atan2(modelUp.x,modelUp.y),time:t,active:running});
 if(running&&!paused){emit(f,Math.ceil((55+Math.abs(heading)*110+stance.pressure*90+boost*100)*dt),.65+stance.pressure*.45,heading>0?-1:1);trail.unshift({q,s});if(trail.length>61)trail.pop();}
 const wa=wg.attributes.position.array;for(let j=0;j<=60;j++){for(let i=0;i<=1;i++){const item=trail[Math.min(j,trail.length-1)];const idx=(j*2+i)*3;if(item){const p=surface(item.q+(i?1:-1)*(.018+j*.00045),item.s-1.1,t);const n=frame(item.q,item.s,t).normal;p.addScaledVector(n,.035);wa[idx]=p.x;wa[idx+1]=p.y;wa[idx+2]=p.z;}else wa[idx+1]=-1000;}}wg.attributes.position.needsUpdate=true;
 for(let i=0;i<count;i++){const k=i*3;if(life[i]>0){life[i]-=dt;pv[k+1]-=dt*5.5;pp[k]+=pv[k]*dt;pp[k+1]+=pv[k+1]*dt;pp[k+2]+=pv[k+2]*dt;const fade=clamp(life[i]*2,0,1);pcol[k]=pcol[k+1]=pcol[k+2]=fade;}else{pp[k+1]=-1000;pcol[k]=pcol[k+1]=pcol[k+2]=0;}}pg.attributes.position.needsUpdate=true;pg.attributes.color.needsUpdate=true;
 // Sparse wind-carried crest spray, added to the same bounded pool.
 if(running){for(let j=0;j<Math.ceil(dt*100);j++){const dist=s-5+Math.random()*60;const cf=frame(1.18,dist,t);emit(cf,1,.6);}}
 fan.update(dt,snap>=0?f:null);
 const desired=new T.Vector3(f.p.x-1.85,f.p.y*.90+1.9,-s+4.35+Math.max(0,1.0-camera.aspect)*.7);
 const aim=new T.Vector3(f.p.x-.75,f.p.y+.70,-s-2.8);
 if(!ready){cam.copy(desired);look.copy(aim);ready=true;}
 cam.lerp(desired,1-Math.exp(-dt*5));look.lerp(aim,1-Math.exp(-dt*5.5));camera.position.copy(cam);up.set(Math.sin(lean*.035),1,0).normalize();camera.up.lerp(up,1-Math.exp(-dt*3));camera.lookAt(look);camera.fov=damp(camera.fov,55+clamp(speed-18,0,10)*.35+boost*.7,2.5,dt);camera.updateProjectionMatrix();
 sky.position.z=-s;far.position.z=-s;clouds.position.z=-s*.8;islands.position.z=-Math.floor(s/650)*650;
 document.body.dataset.phase='surf';$('speed').textContent=`${Math.round(speed*3.6)} km/h`;$('time').textContent=`00:${String(Math.ceil(Math.max(0,15-elapsed))).padStart(2,'0')}`;$('score').textContent=Math.floor(score).toLocaleString();$('waveNumber').textContent='CLEAR DAY';
 $('waveStatus').textContent=snap>=0?'LIP SNAP':q<.32?'D → DRIVE BACK UP THE FACE':q>.76?'LIP · KEEP TURNING RIGHT TO SNAP':'A ← DROP / D → CLIMB';
 if(toastTime>0){toastTime-=dt;if(toastTime<=0)$('message').textContent='';}
 renderer.render(scene,camera);
}
$('start').onclick=start;$('quickSurf').onclick=start;$('again').onclick=start;$('sound').onclick=()=>{muted=!audio.toggle();$('sound').textContent=muted?'Sound off':'Sound on';};
window.addEventListener('keydown',e=>{if(['Space','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();if(e.code==='KeyR')start();if(e.code==='KeyP'&&running){paused=!paused;toast(paused?'PAUSED · P TO RESUME':'FIND YOUR LINE');}if(e.code==='KeyM')$('sound').click();if((e.code==='KeyS'||e.code==='Space')&&running&&!paused)doSnap();keys[e.code]=true;});
window.addEventListener('keyup',e=>keys[e.code]=false);window.addEventListener('blur',()=>{Object.keys(keys).forEach(k=>keys[k]=false);if(running){paused=true;toast('PAUSED · P TO RESUME');}});
for(const b of document.querySelectorAll('[data-key]')){b.onpointerdown=e=>{b.setPointerCapture(e.pointerId);keys[b.dataset.key]=true;if(b.dataset.key==='Space')doSnap();};b.onpointerup=b.onpointercancel=()=>keys[b.dataset.key]=false;}
const clock=new T.Clock();function animate(){requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.04);if(!paused){t+=dt;if(running){acc+=dt;while(acc>=1/120){step(1/120);acc-=1/120;}}render(dt);}audio.update({speed,steer:heading,air:false,paused,running,time:t,u:q*4,landing:boost});}animate();
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
