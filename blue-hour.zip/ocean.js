// A pitching sheet and persistent, wind-carried crest droplets.
export function makeOceanEffects(T,scene,map,surface){
 const count=180,columns=14,geo=new T.PlaneGeometry(1,1,columns,count);
 const material=new T.MeshStandardMaterial({color:0x31aace,roughness:.27,metalness:.02,emissive:0x0c4c77,emissiveIntensity:.07,side:T.DoubleSide,vertexColors:true,transparent:true,opacity:.93,depthWrite:false});
 const lipFade=new Float32Array(geo.attributes.position.count);geo.setAttribute('lipFade',new T.BufferAttribute(lipFade,1));const color=new Float32Array(geo.attributes.position.count*3);geo.setAttribute('color',new T.BufferAttribute(color,3));
 const sheet=new T.Mesh(geo,material);sheet.frustumCulled=false;scene.add(sheet);
 const noise=`float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);} float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1)),f.x),f.y);}`;
 const uniforms={time:{value:0}};
 material.onBeforeCompile=sh=>{sh.uniforms.oceanTime=uniforms.time;sh.vertexShader=sh.vertexShader.replace('#include <common>','#include <common>\nattribute float lipFade; varying float vLipFade; varying vec2 lipUv; varying vec3 lipP;').replace('#include <begin_vertex>','#include <begin_vertex>\nlipUv=uv;lipP=position;vLipFade=lipFade;');sh.fragmentShader=sh.fragmentShader.replace('#include <common>','#include <common>\nuniform float oceanTime; varying float vLipFade; varying vec2 lipUv; varying vec3 lipP;\n'+noise).replace('#include <color_fragment>',`#include <color_fragment>
vec2 p=vec2(lipP.z*.9-oceanTime,lipUv.x*9.+oceanTime*.5);
diffuseColor.a*=vLipFade;
float n=noise(p+noise(p*.4)*3.);float fine=noise(p*5.7);
float foam=smoothstep(.25,.9,lipUv.x+n*.35)*smoothstep(.28,.7,n+fine*.18);
foam*=.55+.45*noise(p*9.3+noise(p*2.1)*2.);
diffuseColor.rgb=mix(diffuseColor.rgb,vec3(.98,1.,.98),foam*.95);
`).replace('#include <emissivemap_fragment>','#include <emissivemap_fragment>\ntotalEmissiveRadiance+=vec3(.12,.16,.14)*foam;');};
 function lip(dist,t,v){
 const p=surface(12+localCurl(dist)*13,dist,t), pulse=.5+.5*Math.sin(dist*.085-t*.95);
 const curl=v*(1.25+pulse*.65), r=.65+pulse*.5;
 p.x-=Math.sin(curl)*r;
 p.y-=r*(1-Math.cos(curl))+v*v*(.3+pulse*.5);
 p.z+=Math.sin(dist*.43-t*1.4)*v*.10;
 return p;
 }
 function particles(n,size,opacity){const g=new T.BufferGeometry(),pos=new Float32Array(n*3),col=new Float32Array(n*3),life=new Float32Array(n),total=new Float32Array(n),vel=new Float32Array(n*3);g.setAttribute('position',new T.BufferAttribute(pos,3));g.setAttribute('color',new T.BufferAttribute(col,3));const m=new T.PointsMaterial({map,size,opacity,transparent:true,depthWrite:false,vertexColors:true,color:0xffffff});const points=new T.Points(g,m);points.frustumCulled=false;m.onBeforeCompile=shader=>{shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
diffuseColor.a*=vColor.r;diffuseColor.rgb=vec3(1.,1.,1.);`);};scene.add(points);pos.fill(-1000);return {g,pos,col,life,total,vel,n,m};}
 const drops=particles(3400,.16,.90),mist=particles(600,.82,.12);
 function updateParticles(p,dt,s,t,isMist){for(let i=0;i<p.n;i++){let j=i*3;p.life[i]-=dt;if(p.life[i]<=0){let dist=s-28+Math.random()*165;for(let j=0;j<4&&localCurl(dist)>.94;j++)dist+=25;const v=Math.random();const origin=lip(dist,t,.5+v*.5);p.pos[j]=origin.x;p.pos[j+1]=origin.y;p.pos[j+2]=origin.z;p.total[i]=p.life[i]=(isMist?2.2:1.1)+Math.random()*1.5;p.vel[j]=-.5-Math.random()*2.1;p.vel[j+1]=isMist?1+Math.random()*1.6:.6+Math.random()*2.3;p.vel[j+2]=1+Math.random()*2;}p.vel[j+1]-=dt*(isMist?.55:5.5);p.pos[j]+=p.vel[j]*dt;p.pos[j+1]+=p.vel[j+1]*dt;p.pos[j+2]+=p.vel[j+2]*dt;const age=1-p.life[i]/p.total[i];const fade=Math.sin(age*Math.PI)*.9;p.col[j]=fade*.88;p.col[j+1]=fade;p.col[j+2]=fade;}p.g.attributes.position.needsUpdate=true;p.g.attributes.color.needsUpdate=true;}
 let warm=false,barrel=0,localCurl=()=>barrel;
 return {update(dt,s,t,strength=1,tube=0,curlAt=null){barrel=tube;localCurl=curlAt||(()=>barrel);sheet.visible=strength>.25;drops.m.opacity=.9*strength;mist.m.opacity=.12*strength;uniforms.time.value=t;const a=geo.attributes.position.array;let k=0;for(let j=0;j<=count;j++){const dist=s-45+j/count*280;for(let i=0;i<=columns;i++){const v=i/columns,p=lip(dist,t,v);lipFade[k/3]=1-T.MathUtils.smoothstep(localCurl(dist),.84,.98);a[k]=p.x;a[k+1]=p.y;a[k+2]=p.z;const c=.55+v*.4;color[k]=c;color[k+1]=c;color[k+2]=c;k+=3;}}geo.attributes.position.needsUpdate=true;geo.attributes.color.needsUpdate=true;geo.attributes.lipFade.needsUpdate=true;geo.computeVertexNormals();if(!warm){for(let i=0;i<50;i++){updateParticles(drops,.04,s,t,false);updateParticles(mist,.04,s,t,true);}warm=true;}updateParticles(drops,dt,s,t,false);updateParticles(mist,dt,s,t,true);},reset(){drops.life.fill(0);mist.life.fill(0);warm=false;}};
}

export function makeSurfAudio(){
 let ctx,master,sea,rail,wind,seaFilter,railFilter,windFilter,panner,enabled=true,started=false,error='';
 function init(){try{if(!ctx){ctx=new (window.AudioContext||window.webkitAudioContext)();master=ctx.createGain();master.gain.value=0;const limiter=ctx.createDynamicsCompressor();limiter.threshold.value=-18;limiter.ratio.value=4;master.connect(limiter);limiter.connect(ctx.destination);
 const buffer=ctx.createBuffer(2,ctx.sampleRate*7,ctx.sampleRate);for(let c=0;c<2;c++){const d=buffer.getChannelData(c);let last=0;for(let i=0;i<d.length;i++){last=(last+.025*(Math.random()*2-1))/1.025;d[i]=last*8;}}
 const white=ctx.createBuffer(2,ctx.sampleRate*7,ctx.sampleRate);for(let c=0;c<2;c++){const d=white.getChannelData(c);for(let i=0;i<d.length;i++)d[i]=(Math.random()*2-1)*.45;}
 function layer(type,freq,q){const src=ctx.createBufferSource();src.buffer=type==='lowpass'?buffer:white;src.loop=true;const filter=ctx.createBiquadFilter();filter.type=type;filter.frequency.value=freq;filter.Q.value=q;const gain=ctx.createGain();gain.gain.value=0;src.connect(filter);filter.connect(gain);src.start(0,Math.random()*5);return {gain,filter};}
 const a=layer('lowpass',650,.5);sea=a.gain;seaFilter=a.filter;sea.connect(master);const b=layer('bandpass',1700,.6);rail=b.gain;railFilter=b.filter;panner=ctx.createStereoPanner();rail.connect(panner);panner.connect(master);const c=layer('highpass',2500,.5);wind=c.gain;windFilter=c.filter;wind.connect(master);
 }ctx.resume().catch(e=>{error=e.message;});started=true;}catch(e){error=e.message;}}
 function smooth(param,value,tau=.13){param.setTargetAtTime(value,ctx.currentTime,tau);}
 return {start:init,toggle(){enabled=!enabled;if(enabled)init();return enabled;},update({speed,steer,air,paused,running,time,u,landing}){if(!ctx)return;const active=enabled&&running&&!paused; smooth(master.gain,active?.55:0,.15);const velocity=Math.max(0,(speed-10)/22);const swell=.5+.5*Math.sin(time*.68);smooth(sea.gain,.38+swell*.13+Math.max(0,u)*.012);smooth(seaFilter.frequency,400+swell*240+Math.max(0,u)*25);smooth(rail.gain,air?.025:.10+velocity*.24+Math.abs(steer)*velocity*.45+landing*.28,.065);smooth(railFilter.frequency,900+velocity*1900+Math.abs(steer)*2000,.08);smooth(panner.pan,steer*.6,.1);smooth(wind.gain,.025+velocity*.16+(air?.10:0));},status(){return {started,enabled,state:ctx?.state||'uninitialized',error,master:master?.gain.value,rail:rail?.gain.value,railFrequency:railFilter?.frequency.value};}};
}
