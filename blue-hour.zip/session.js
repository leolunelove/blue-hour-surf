import {wavePlan,pocketAt} from './waves.js?v=2';
// Pure, fixed-step game rules. Rendering, input and storage are separate clients.
export const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const mix=(a,b,t)=>a+(b-a)*t, damp=(a,b,k,dt)=>mix(a,b,1-Math.exp(-k*dt));
export const BOARDS={
 sunfish:{id:'sunfish',name:'Sunfish',subtitle:'Forgiving & steady',turn:5.8,maxSpeed:27,pump:1,landing:.62,color:'#ffd32d',width:1,length:1},
 reef:{id:'reef',name:'Reef',subtitle:'Fast rails · precise landings',turn:8.2,maxSpeed:29,pump:1.15,landing:.38,color:'#75e4d5',width:.90,length:.94}
};
export const GOALS=[{id:'flow',title:'Find your rhythm',detail:'Link 3 moves in one line, using at least 2 move types.'},{id:'air',title:'Above the lip',detail:'Link a lip snap and a clean aerial in the same line.'},{id:'rival',title:'Beat the local',detail:'Bank 6,000 points in a session. Pip’s best: 6,000.'}];
export function cleanSave(raw={}){const badges=Array.isArray(raw?.badges)?[...new Set(raw.badges.filter(x=>GOALS.some(g=>g.id===x)))]:[];return {version:1,badges,best:Number.isFinite(raw?.best)?clamp(Math.floor(raw.best),0,1e8):0,board:raw?.board==='reef'&&badges.length>=2?'reef':'sunfish',sessions:Number.isSafeInteger(raw?.sessions)?clamp(raw.sessions,0,1e6):0};}
export function loadSave(storage){try{return cleanSave(JSON.parse(storage.getItem('blue-hour-progress-v1')||'{}'));}catch{return cleanSave();}}
export function writeSave(storage,save){try{storage.setItem('blue-hour-progress-v1',JSON.stringify(cleanSave(save)));return true;}catch{return false;}}
export class SurfSession{
 constructor(save={}){this.save=cleanSave(save);this.events=[];this.reset();}
 reset(){this.board=BOARDS[this.save.board];this.phase='ready';this.elapsed=0;this.wave=1;this.waveTime=0;this.transition=0;this.q=.83;this.s=0;this.speed=17;this.heading=-.68;this.lean=0;this.crouch=.2;this.charge=0;this.boost=0;this.snap=-1;this.recovery=0;this.snapArmed=true;this.turnArmed=false;this.cutArmed=false;this.cutDistance=0;this.lastQ=this.q;this.air=null;this.banked=0;this.line=0;this.multiplier=1;this.linkTime=0;this.moves=[];this.recent=[];this.repeats={};this.shoulderTime=0;this.stats={bottoms:0,snaps:0,cuts:0,airs:0,rough:0,wipes:0,banks:0,bestLine:0,maxSpeed:17};this.events=[];this.finishedSaved=false;this.cycle=0;this.previousInput=0;this.lastSnapAt=-100;this.previousHeading=this.heading;this.comboLost=0;this.airBuffer=0;this.closeoutAssisted=false;return this;}
 start(){this.reset();this.phase='surf';this.event('wave','DROP IN · A left to load, D right to drive');}
 equip(id){if(this.phase==='surf'||this.phase==='air'||this.phase==='recover'||this.phase==='between')return false;if(id==='reef'&&this.save.badges.length<2)return false;if(!BOARDS[id])return false;this.save.board=id;this.board=BOARDS[id];this.event('save');return true;}
 event(type,text='',extra={}){this.events.push({type,text,...extra});}
 drain(){return this.events.splice(0);}
 awardGoal(id){if(this.save.badges.includes(id))return;const wasUnlocked=this.save.badges.length>=2;this.save.badges.push(id);this.event('goal',GOALS.find(g=>g.id===id).title,{id});if(!wasUnlocked&&this.save.badges.length>=2)this.event('unlock','REEF UNLOCKED · choose it after this session');this.event('save');}
 move(type,label,base,quality=1){
 const repeat=this.repeats[type]||0;this.repeats[type]=repeat+1;
 const same=this.moves.at(-1)===type;const variety=same?.35:Math.max(.45,1-repeat*.13);
 if(!same)this.multiplier=Math.min(5,1+this.moves.length*.35);
 const value=Math.round(base*quality*variety*this.multiplier);this.line+=value;this.moves.push(type);this.recent.push(label);if(this.recent.length>3)this.recent.shift();this.linkTime=6.5;this.shoulderTime=0;
 this.event('move',`${label} +${value}`,{move:type,value,same,quality});
 const unique=new Set(this.moves);if(this.moves.length>=3&&unique.size>=2)this.awardGoal('flow');if(unique.has('snap')&&unique.has('air'))this.awardGoal('air');
 }
 bank(reason='LINE BANKED',retention=1){if(this.line<=0)return 0;const points=Math.round(this.line*retention);this.banked+=points;this.stats.bestLine=Math.max(this.stats.bestLine,points);this.stats.banks++;this.clearLine();this.event('bank',`${reason} +${points.toLocaleString()}`,{value:points,full:retention===1});if(this.banked>=6000)this.awardGoal('rival');return points;}
 clearLine(){this.line=0;this.multiplier=1;this.linkTime=0;this.moves=[];this.repeats={};this.recent=[];}
 loseLine(){const lost=this.line;this.clearLine();if(lost){this.comboLost=1;this.event('lost',`LINE LOST · ${lost.toLocaleString()} at risk`,{value:lost});}}
 snapMove(){if(this.phase!=='surf'||this.snap>=0||this.recovery>0||!this.snapArmed||this.q<.72)return false;this.snap=0;this.recovery=1.18;this.snapArmed=false;this.lastSnapAt=this.elapsed;this.stats.snaps++;this.boost=.65;this.speed=Math.max(14,this.speed*.96);this.move('snap',this.speed>18?'CLEAN SNAP':'LIP SNAP',210+this.speed*5,this.speed>18?1.15:1);this.event('spray','',{power:1.7});return true;}
 launch(){if(this.phase!=='surf'||this.snap>=0||this.recovery>.1||this.q<(pocketAt(this.s,this.elapsed).ramp>.4?.54:.65)||this.speed<17.2||this.waveTime<.8){this.event('hint','AIR · build speed, then press Space near the lip');return false;}this.air={pocket:pocketAt(this.s,this.elapsed).ramp>.4,age:0,duration:1.18+Math.min(.18,(this.speed-18)*.015),startQ:this.q,landingQ:.36,lean:0,height:0,spin:0};this.phase='air';this.airBuffer=0;this.boost=.55;this.event('launch','AIR · release steering to line up the landing');return true;}
 wipe(reason='WHITEWATER'){this.bank('RESCUED LINE',.65);this.stats.wipes++;this.air=null;this.phase='recover';this.transition=2;this.snap=-1;this.recovery=0;this.speed*=.45;this.event('wipe',`${reason} · next wave in 2s`);}
 nextWave(){this.wave++;this.closeoutAssisted=false;this.waveTime=0;this.phase='surf';this.q=.83;this.heading=-.68;this.speed=17;this.charge=0;this.snap=-1;this.recovery=0;this.snapArmed=true;this.turnArmed=false;this.cutArmed=false;this.air=null;this.event('wave',`WAVE ${this.wave} · FIND YOUR LINE`);}
 finish(){if(this.phase==='finished')return;this.bank('LAST LINE BANKED');this.phase='finished';this.air=null;this.save.best=Math.max(this.save.best,this.banked);this.save.sessions++;this.event('finish');this.event('save');}
 plan(){return wavePlan(this.wave);}
 section(){const p=this.plan();return this.waveTime<p.lip?{id:'open',name:p.name,hint:'A · load the lower face → D · drive a bottom turn'}:this.waveTime<p.close?{id:'lip',name:'PEELING LIP',hint:'S · snap at the crest · Space · launch with speed'}:{id:'closing',name:'OPEN SHOULDER',hint:'Drop low to bank the line · whitewater guides you out'};}
 opportunity(){const section=pocketAt(this.s,this.elapsed);if(this.phase==='air')return 'RELAX THE RAIL · SOFT LANDING';if(this.phase!=='surf')return 'NEXT SWELL ROLLING IN';if(this.waveTime>this.plan().close&&this.line)return 'B · BANK YOUR LINE ON THE LOWER FACE';if(section.ramp>.5&&this.q>.5&&this.speed>=17.2)return 'RAMP · SPACE TO LAUNCH';if(section.pocket>.55&&this.q<.55)return 'POCKET · LOAD LOW AND DRIVE RIGHT';if(this.q>.65&&this.speed>=17.2&&this.recovery<=.1)return 'SPACE · LAUNCH  /  S · SNAP';if(this.q<.36&&this.charge>.22)return 'D → DRIVE · RELEASE YOUR SPEED';if(this.heading>0)return 'CLIMB TO THE LIP · SNAP OR LAUNCH';return 'A ← DROP LOW · LOAD YOUR NEXT CARVE';}

 update(dt,{steer=0,snap=false,air=false,bank=false}={}){
 if(!['surf','air','recover','between'].includes(this.phase))return;
 dt=clamp(dt,0,.05);steer=clamp(Number.isFinite(steer)?steer:0,-1,1);this.elapsed=Math.min(120,this.elapsed+dt);this.boost=Math.max(0,this.boost-dt);this.comboLost=Math.max(0,this.comboLost-dt);
 if(this.elapsed>=120){this.finish();return;}
 if(this.phase==='recover'||this.phase==='between'){this.transition-=dt;this.speed=damp(this.speed,8,2,dt);this.s+=this.speed*dt;this.q=damp(this.q,.10,1.8,dt);this.heading=damp(this.heading,0,4,dt);this.lean=damp(this.lean,0,5,dt);this.crouch=damp(this.crouch,.25,5,dt);if(this.transition<=0)this.nextWave();return;}
 this.waveTime+=dt;this.airBuffer=Math.max(0,this.airBuffer-dt);if(air)this.airBuffer=.65;
 if(this.line>0){this.linkTime-=dt;if(this.linkTime<=0){this.bank('FLOW SAVED · 70%',.7);}}
 if(this.phase==='air'){
  const a=this.air;a.age+=dt;const f=clamp(a.age/a.duration,0,1);a.height=Math.sin(f*Math.PI)*(2.1+(this.speed-18)*.08);a.landingQ=clamp(a.landingQ+steer*dt*.28,.10,.91);a.lean=damp(a.lean,steer*.85*(1-.65*clamp((f-.55)/.45,0,1)),6,dt);a.spin=Math.sin(f*Math.PI)*a.lean*.55;this.s+=this.speed*.90*dt;this.q=mix(a.startQ,a.landingQ,f*f*(3-2*f));this.heading=damp(this.heading,-.25+steer*.35,3,dt);this.crouch=damp(this.crouch,.75,8,dt);
  if(f>=1){const clean=Math.abs(a.lean)<=this.board.landing&&a.landingQ<.86;this.air=null;this.phase='surf';this.heading=-.48;this.recovery=.25;this.snapArmed=false;this.boost=clean?.75:.15;
   this.q=clamp(this.q,.12,.79);
   if(clean){this.stats.airs++;this.speed=Math.min(this.board.maxSpeed,this.speed+1);this.move('air',a.pocket?'POCKET AIR':'CLEAN AIR',a.pocket?600:480,1.15);this.event('land','CLEAN LANDING',{clean:true});}
   else{this.stats.rough++;this.speed=Math.max(12,this.speed-2);this.line=Math.round(this.line*.85);this.linkTime=Math.min(this.linkTime,4);this.event('land','LANDING SAVED · flow straight into your next carve',{clean:false});}
  }
 }else{
  this.recovery=Math.max(0,this.recovery-dt);if(this.snap>=0){this.snap+=dt;if(this.snap>.72)this.snap=-1;}
  const previous=this.heading;
  let target=steer*.90;if(this.snap>=0)target=mix(.6,-1,clamp(this.snap/.22,0,1));else if(this.recovery>0)target=mix(target,-.80,clamp(this.recovery/.46,0,1));
  if(this.waveTime<.60)target=-.68;if(this.q<-.03&&target<0)target=-.1;
  this.heading=damp(this.heading,target,this.snap>=0?14:this.board.turn,dt);
  const descent=-Math.sin(this.heading);const slope=clamp(this.q*1.8,0,1);
  this.charge=clamp(this.charge+(descent>.18&&this.q>.12?descent*1.15:-.18)*dt,0,1);
  if(this.q<.36&&this.heading<-.18&&this.charge>.22)this.turnArmed=true;
  if(this.turnArmed&&steer>.25&&previous<=.08&&this.heading>.08&&this.recovery<=0){const gain=(2.4+this.charge*3.1)*this.board.pump;this.speed+=gain;this.charge=0;this.turnArmed=false;this.cycle++;this.stats.bottoms++;this.boost=.8;this.move('bottom','BOTTOM TURN',130+gain*25);this.event('pump',`PUMP +${Math.round(gain*3.6)} km/h`,{gain});}
  if(this.q>.48&&this.q<.80&&this.heading>.35&&this.recovery<=0){this.cutArmed=true;this.cutDistance=this.q;}
  if(this.cutArmed&&steer<-.25&&previous>=-.08&&this.heading<-.08&&this.recovery<=0&&this.q>.38&&this.q<.84&&this.speed>15){this.cutArmed=false;this.stats.cuts++;this.move('cut','CUTBACK',190);}
  if(this.q<.40)this.snapArmed=true;
  this.speed+=((14-this.speed)*.19+descent*slope*6.8-Math.abs(steer)*.24)*dt;this.speed=clamp(this.speed,10,this.board.maxSpeed);this.stats.maxSpeed=Math.max(this.stats.maxSpeed,this.speed);
  this.q=clamp(this.q+Math.sin(this.heading)*this.speed*.036*dt,-.06,.965);this.s+=Math.max(.65,Math.cos(this.heading))*this.speed*dt;
  if(this.airBuffer>0&&this.q>=(pocketAt(this.s,this.elapsed).ramp>.4?.54:.65)&&this.speed>=17.2&&this.waveTime>=.8&&this.snap<0&&this.recovery<=.1)this.launch();else if(snap||(this.q>=.95&&this.heading>.08)){
   const hit=this.snapMove();if(!hit&&this.q>=.95&&this.snap<0&&this.recovery<=0){this.snap=0;this.recovery=1.18;this.event('hint','DROP LOWER · load your next snap');}
  }
  if(this.q<.075&&this.line>0){this.shoulderTime+=dt;if(this.shoulderTime>.45)this.bank('SHOULDER · BANKED');}else this.shoulderTime=0;
  if(bank){if(this.q<.32)this.bank();else this.event('hint','BANK · drop to the lower face first');}
  this.lean=damp(this.lean,this.heading,8,dt);this.crouch=damp(this.crouch,.12+Math.abs(steer)*.20+Math.max(0,descent)*.16+this.charge*.16+(this.snap>=0?Math.sin(this.snap/.72*Math.PI)*.22:0),9,dt);
 }
 if(this.waveTime>this.plan().close+1.5&&this.q>.76&&this.speed<15.5&&this.phase==='surf'&&!this.closeoutAssisted){this.closeoutAssisted=true;this.heading=-.7;this.recovery=.65;this.speed=Math.max(17,this.speed);this.bank('WHITEWATER SAVE · 85%',.85);this.event('hint','FOAM BOOST · FOLLOW THE OPEN SHOULDER');}
 if(this.waveTime>=this.plan().duration&&this.phase!=='air'){this.bank('WAVE COMPLETE');this.phase='between';this.air=null;this.transition=2;this.event('between','NEXT SWELL · 2 SECONDS');}
 if(air&&this.phase==='surf'&&(this.q<.50||this.speed<17.2))this.event('hint','AIR · load a bottom turn, then Space near the lip');this.previousInput=steer;this.lastQ=this.q;
 }
}
